# if with bad `sectors` errors gracefully

    Each value of `sectors` must be one of these:
    automotive, aviation, cement, coal, oil&gas, power, shipping, steel.
    x You passed: bad.
    i Do you need to see valid values in this dataset?:
    sector_colours

---

    Each value of `sectors` must be one of these:
    automotive, aviation, cement, coal, oil&gas, power, shipping, steel.
    x You passed: bad.
    i Do you need to see valid values in this dataset?:
    sector_colours

