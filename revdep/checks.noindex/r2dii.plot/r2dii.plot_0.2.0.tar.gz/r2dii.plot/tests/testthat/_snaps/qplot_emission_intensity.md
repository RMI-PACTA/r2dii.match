# Prints title as expected

    Emission Intensity Trend for the Automotive Sector

# Prints axis labels as expected

    [1] "Year"

---

    [1] "Tons of CO2 per Ton of Production Unit"

