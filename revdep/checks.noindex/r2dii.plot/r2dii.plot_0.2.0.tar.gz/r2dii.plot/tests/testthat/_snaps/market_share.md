# outputs the expected snapshot

    Code
      some_market_share
    Output
            sector technology year region scenario_source            metric
      1 automotive   electric 2020 global       demo_2020         projected
      2 automotive   electric 2020 global       demo_2020 corporate_economy
      3 automotive   electric 2020 global       demo_2020        target_cps
      4 automotive   electric 2020 global       demo_2020        target_sds
      5 automotive   electric 2020 global       demo_2020        target_sps
      6 automotive   electric 2021 global       demo_2020         projected
        production technology_share
      1   145942.3       0.18274621
      2  8134868.7       0.05662567
      3   145942.3       0.06488835
      4   145942.3       0.06488835
      5   145942.3       0.06488835
      6   148211.7       0.18265671

