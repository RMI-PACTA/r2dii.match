# outputs the expected snapshot

    Code
      sda
    Output
      # A tibble: 208 x 4
         sector      year emission_factor_metric emission_factor_value
         <chr>      <dbl> <chr>                                  <dbl>
       1 automotive  2002 projected                              0.228
       2 automotive  2003 projected                              0.226
       3 automotive  2004 projected                              0.224
       4 automotive  2005 projected                              0.222
       5 automotive  2006 projected                              0.220
       6 automotive  2007 projected                              0.218
       7 automotive  2008 projected                              0.216
       8 automotive  2009 projected                              0.214
       9 automotive  2010 projected                              0.212
      10 automotive  2011 projected                              0.210
      # ... with 198 more rows

