# if with bad `labels` errors gracefully

    Each value of `labels` must be one of these:
    dark_blue, green, orange, grey, dark_purple, yellow, soft_blue, ruby_red, moss_green.
    x You passed: bad.
    i Do you need to see valid values in this dataset?:
    palette_colours

---

    Each value of `labels` must be one of these:
    dark_blue, green, orange, grey, dark_purple, yellow, soft_blue, ruby_red, moss_green.
    x You passed: bad.
    i Do you need to see valid values in this dataset?:
    palette_colours

