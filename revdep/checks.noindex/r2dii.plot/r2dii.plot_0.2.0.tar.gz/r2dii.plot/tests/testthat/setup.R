op <- options(r2dii.plot.quiet = TRUE)
on.exit(op, add = TRUE)
