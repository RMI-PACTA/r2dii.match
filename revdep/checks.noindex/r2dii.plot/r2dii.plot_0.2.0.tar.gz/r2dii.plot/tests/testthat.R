library(testthat)
library(r2dii.plot)

test_check("r2dii.plot")
