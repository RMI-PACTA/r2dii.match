# with fake data outputs known value

    Code
      out
    Output
      # A tibble: 1 x 22
        id_loan loan_size_outstand~ loan_size_outst~ loan_size_credi~ loan_size_credi~
        <chr>                 <dbl> <chr>                       <dbl> <chr>           
      1 L162                      1 EUR                             2 EUR             
      # ... with 17 more variables: id_2dii <chr>, level <chr>, score <dbl>,
      #   sector <chr>, name_abcd <chr>, sector_abcd <chr>, technology <chr>,
      #   year <dbl>, production <dbl>, emission_factor <dbl>, plant_location <chr>,
      #   is_ultimate_owner <lgl>, scenario <chr>, region <chr>, tmsr <dbl>,
      #   smsp <dbl>, scenario_source <chr>

