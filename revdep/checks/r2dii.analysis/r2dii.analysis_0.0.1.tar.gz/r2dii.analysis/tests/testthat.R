library(testthat)
library(r2dii.analysis)

test_check("r2dii.analysis")
