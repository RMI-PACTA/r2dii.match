# Avoid failure on CI due to difference in print width between local vs. CI
options(tibble.width = 60)
