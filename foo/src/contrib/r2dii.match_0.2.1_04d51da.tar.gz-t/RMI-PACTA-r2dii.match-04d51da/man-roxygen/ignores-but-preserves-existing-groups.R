#' @section Handling grouped data:
#' This function ignores but preserves existing groups.
