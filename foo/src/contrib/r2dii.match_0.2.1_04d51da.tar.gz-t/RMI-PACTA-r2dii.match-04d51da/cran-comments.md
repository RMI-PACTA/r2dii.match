## R CMD check results

0 errors | 0 warnings | 0 notes
